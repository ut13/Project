
 <?php include("header.php") ?>

    <!-- home
    ================================================== -->
    <section id="home" class="s-home target-section">

 
        <div class="home-content">

            <div class="row home-content__main wide">
                   
                    <video autoplay muted loop id="myVideo">
                            <source src="exfx.mp4" type="video/mp4">
                          </video>
                        
                          
                          <!-- Optional: some overlay text to describe the video -->
                          <div class="content">
                            <h2>Personalize Your Customers<br> Shopping Experience</h2>
                          </div>

                                     
            </div> <!-- end home-content__main -->

           
  
        </div> <!-- end home-content -->

    </section> <!-- end s-home -->


 
 <section id="process" class="s-process">
<div class="row">
<div class="col-full text-center" data-aos="fade-up">
<h2 class="display-2">Why EXFX?</h2>
</div>
</div>
<div class="row process block-1-2 block-m-1-2 block-tab-full">
<div class="col-block item-process " data-aos="fade-up">
<div class="item-process__text">

    <center>
    <p style="margin-top: 1rem !important; font-weight: 500;">
    <img src="images2/gal (7).jpg" style="width: 70%; margin-bottom: 1rem;"><br>
    Get access to cutting edge marketing technology
    </p>
    </center>

</div>
</div>
<div class="col-block item-process" data-aos="fade-up">
<div class="item-process__text">
 
  <center>
    <img src="images2/gal (4).jpg" style="width: 70%; margin-top: 1rem;" ><br>
     <p style="margin-top: 1rem !important; font-weight: 500;">

     Built for business of all scale and sizes
    </p>
    </center>

</div>
</div>
</div>
<div class="row process block-1-2 block-m-1-2 block-tab-full">

<div class=" item-process aos-init" data-aos="fade-up">
          <center>

<div class="item-process__text">


    <img src="images2/g9.jpg" style="width: 35%"><br>
    <p style="margin-top: 1rem !important; font-weight: 500;">
   Allow your customers to touch or feel the merchandise
    </p>

</div>
    </center>

</div>

</div>

<div class="row process block-1-2 block-m-1-2 block-tab-full">

<div class="col-block item-process" data-aos="fade-up">
<div class="item-process__text">
  
   <center>
    <img src="images2/laptop.jpg" style="width: 68%">
        <p style="margin-top: 1rem !important; font-weight: 500;">
   Low cost marketing and high return on investment
     </p>
    </center>
 
</div>
</div>


<div class="col-block item-process" data-aos="fade-up">
<div class="item-process__text">
  
   <center>
  
    <img src="images2/women.jpg" style="width: 70%"><br>
        <p style="margin-top: 1rem !important; font-weight: 500;">
               One step access to customer engagement and retention
</p>
    </center>
 
</div>
</div>

</div> 
 
</section>
    <style>
         .shadow {     
      box-shadow: 0px 15px 10px -15px #111 !important;    


                 }
                 
                 
 
     </style >
  <section class="comments-wrap" style="background-color: #8b9bbc; " >
<div style="height: 12rem; background-color: white"></div>
  
<div class="row">

<div id="respond" class="col-full">
<left>
    <br>
<h3 style="color: white;">SIGN UP FORM</h3>
</left>
<form name="contactForm" id="contactForm" method="post" action="" autocomplete="off">
<fieldset>
<div class="form-field col-half">
<input name="cName" id="cName" required="" class="full-width" placeholder="Contact Name" value="" type="text">
</div>
<div class="form-field col-half">
    <select id="cType" class="full-width" required="" placeholder="Contact Name">
        <option selected disabled>Select</option>
        <option>Service</option>
        <option>Product</option>
    </select>
    </div>
<div class="form-field col-half">
<input name="cCompany" id="cCompany" required="" class="full-width" placeholder="Company name" value="" type="text">
</div>
<div class="form-field col-half">
 <select id="cType" class="full-width" reqired="" placeholder="Location">
        <option selected disabled>Select</option>
        <option>Ahmedabad</option>
        <option>Chandigarh</option>
        <option>Chennai</option>
        <option>Delhi</option>
        <option>Hyderabad</option>
        <option>Jaipur</option>
        <option>Kolkata</option>
        <option>Mumbai</option>
        <option>Pune</option>
    </select>
</div>
<div class="form-field col-half">
<input name="cEmail" id="cEmail" class="full-width" required="" placeholder="Your Email" value="" type="text">
</div>

<div class="form-field col-half">
<input name="cName" id="cContact" required="" class="full-width" placeholder="Your Contact" value="" type="text">
</div>

<div class="form-field col-full">
<textarea name="cMessage" reqired id="cMessage" required="" placeholder="Type your message here">
</textarea>
</div>

<div class="form-field col-full">
<center>
<input name="submit" id="submit" class="btn btn--primary btn-wide" value="Submit" type="submit" style="height: 4rem !important; border: none !important;  background: rgb(187,71,146);
  background: linear-gradient(176deg, rgba(187,71,146,1) 0%, rgba(219,85,121,1) 35%, rgba(205,79,132,1) 100%);">


</center>
</div>
</form> 
</div>

</div> 
</section>
        <!-- download
    ================================================== -->
    
<style>
.topShadow{
        box-shadow: 0px -15px 10px -15px #111;    
}
</style>
  
 <section id="process" class="s-process topShadow">
<div class="row">
<div class="col-full text-center aos-init aos-animate" data-aos="fade-up">
  <center>
                    For more information, reach us at <b>partner@goexfx.com</b><br><br>
   </center>
 </div>
  
 </div>
 </section>
 <script>
header = true;
</script>
  <?php include("footer.php"); ?>