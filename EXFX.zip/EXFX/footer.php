    <!-- footer
    ================================================== -->
    <footer class="s-footer footer" >

        <div class="row footer__bottom"  >
            
<div   >
      
    </div>

            <div class="col-three tab-full" style="   margin-top: 4rem; " >
                <div class="footer__logo">
                    <center>
                    <a href="index.php">
                        <img src="images2/exfx_logo.png" style="height:100%" class="logo_center" alt="Homepage">
                    </a>
                </center>

                </div>
            </div>

            <div class="col-nine tab-full end footer_mob" style="   margin-top: 4rem; ">
                <ul class="footer__site-links">
                    <li><a class="" href="aboutus.php" title="intro">About us</a></li>
                    <li><a class="" href="EXFXforBrands.php" title="about">EXFX for Brands</a></li>
                    <li><a href="privacy_policy.php" title="features">Privacy Policy</a></li>
               
                <li><a  href="blog.php" title="pricing">Blog</a></li>
                <li><a  href="faq.php" title="pricing">FAQ</a></li>
                <li><a href="termsofservice.php" title="blog">Terms of Service</a></li>	
                </ul>
              
                <div class="cl-copyright">
       
                </div>
                <ul class="footer__social pull-right" style="margin-top: 4rem; margin-bottom: 2rem;">
                        <li><a href="https://www.facebook.com/goexfx" target="_blank"><i class="fab fa-facebook-f" aria-hidden="true"></i></a></li>
                        <li><a href="https://www.linkedin.com/company/goexfx" target="_blank"><i class="fab fa-linkedin" aria-hidden="true"></i></a></li>
                        <li><a href="https://twitter.com/goexfx" target="_blank"><i class="fab fa-twitter" aria-hidden="true"></i></a></li>
                        <li><a href="https://www.instagram.com/goexfx/" target="_blank"><i class="fab fa-instagram" aria-hidden="true"></i></a></li>
                    </ul>
                   
            </div>

        </div>

        <!--<div class="go-top">-->
        <!--    <a class="smoothscroll" title="Back to Top" href="#top"></a>-->
        <!--</div>-->

    </footer> <!-- end s-footer -->


    <!-- Java Script
    ================================================== -->
    <script src="js/jquery-3.2.1.min.js"></script>
    <script src="js/plugins.js"></script>
    <script src="js/main.js"></script>
    <script src="js/jquery.cookieBar.min.js"></script>
    <script>
        $(function() {
  $.cookieBar({
      style: "bottom",
      
  });
 
});

    </script>


</body>